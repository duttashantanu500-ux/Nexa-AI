import { buildSystemPrompt } from "./prompts";
import {
  BusinessContext,
  UserType,
  WorkspaceId,
} from "@/types";

export interface AIRequest {
  workspace: WorkspaceId;
  userType: UserType;
  businessContext: BusinessContext | null;
  memories: { content: string; category: string }[];
  recentMessages: { role: "user" | "assistant"; content: string }[];
  userName?: string;
  imageDataUrl?: string;
  websiteContent?: string;
}

type ProviderId =
  | "groq"
  | "gemini"
  | "openai"
  | "anthropic"
  | "openrouter"
  | "ollama"
  | "auto";

interface ProviderConfig {
  id: ProviderId;
  baseUrl: string;
  model: string;
  apiKeyEnv: string;
  headers?: Record<string, string>;
}

/**
 * Nexa Intelligence – Multi Provider System
 *
 * Users only ever see "Nexa Intelligence".
 * The actual model/provider is controlled here (server-side / env).
 * Easy to switch or add new providers later (including a future custom Nexa model).
 */

const PROVIDERS: Record<Exclude<ProviderId, "auto">, ProviderConfig> = {
  groq: {
    id: "groq",
    baseUrl: "https://api.groq.com/openai/v1",
    model: "llama-3.3-70b-versatile",
    apiKeyEnv: "GROQ_API_KEY",
  },
  gemini: {
    id: "gemini",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
    model: "gemini-2.0-flash",
    apiKeyEnv: "GEMINI_API_KEY",
  },
  openai: {
    id: "openai",
    baseUrl: "https://api.openai.com/v1",
    model: "gpt-4o-mini",
    apiKeyEnv: "OPENAI_API_KEY",
  },
  anthropic: {
    id: "anthropic",
    baseUrl: "https://api.anthropic.com/v1",
    model: "claude-3-5-sonnet-latest",
    apiKeyEnv: "ANTHROPIC_API_KEY",
  },
  openrouter: {
    id: "openrouter",
    baseUrl: "https://openrouter.ai/api/v1",
    model: "meta-llama/llama-3.3-70b-instruct",
    apiKeyEnv: "OPENROUTER_API_KEY",
  },
  ollama: {
    id: "ollama",
    baseUrl: "http://localhost:11434/v1",
    model: "llama3.2",
    apiKeyEnv: "OLLAMA_API_KEY", // usually not needed
  },
};

function getActiveProvider(): ProviderConfig {
  // Priority:
  // 1. Explicit env NEXA_PROVIDER
  // 2. Auto-detect first available key
  // 3. Fallback to groq config (will fail gracefully if no key)

  const forced = (process.env.NEXA_PROVIDER || "").toLowerCase() as ProviderId;

  if (forced && forced !== "auto" && PROVIDERS[forced as Exclude<ProviderId, "auto">]) {
    return PROVIDERS[forced as Exclude<ProviderId, "auto">];
  }

  // Auto mode – pick the first provider that has a key
  const order: Exclude<ProviderId, "auto">[] = [
    "groq",
    "gemini",
    "openai",
    "openrouter",
    "anthropic",
    "ollama",
  ];

  for (const id of order) {
    const config = PROVIDERS[id];
    const key = process.env[config.apiKeyEnv] || process.env.NEXA_API_KEY;
    if (key || id === "ollama") {
      return config;
    }
  }

  // Default fallback
  return PROVIDERS.groq;
}

function getApiKey(config: ProviderConfig): string | null {
  return (
    process.env[config.apiKeyEnv] ||
    process.env.NEXA_API_KEY ||
    null
  );
}

/**
 * Main entry point – this is what the rest of the app calls.
 * Never exposes provider or model name to the UI.
 */
export async function callNexaIntelligence(
  request: AIRequest
): Promise<string> {
  const systemPrompt = buildSystemPrompt({
    workspace: request.workspace,
    userType: request.userType,
    businessContext: request.businessContext,
    memories: request.memories,
    userName: request.userName,
  });

  const messages: { role: "system" | "user" | "assistant"; content: string }[] = [
    { role: "system", content: systemPrompt },
    ...request.recentMessages.map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    })),
  ];

  // Attach website content
  if (request.websiteContent && messages.length > 1) {
    const last = messages[messages.length - 1];
    if (last.role === "user") {
      last.content += `\n\n[Website content provided for analysis]\n${request.websiteContent.slice(0, 12000)}`;
    }
  }

  // Attach image note
  if (request.imageDataUrl && messages.length > 1) {
    const last = messages[messages.length - 1];
    if (last.role === "user") {
      last.content += `\n\n[User attached an image. Analyze it in the context of the current workspace and business goals. Give specific, actionable feedback.]`;
    }
  }

  const provider = getActiveProvider();
  const apiKey = getApiKey(provider);

  // Try real provider first
  if (apiKey || provider.id === "ollama") {
    try {
      const response = await callProvider(provider, apiKey, messages);
      if (response) return response;
    } catch (err) {
      console.error(`[Nexa Intelligence] Provider ${provider.id} failed:`, err);
    }
  }

  // Intelligent fallback (so the product still works without keys)
  return generateFallbackResponse(request);
}

async function callProvider(
  config: ProviderConfig,
  apiKey: string | null,
  messages: { role: string; content: string }[]
): Promise<string | null> {
  // Anthropic has a different API shape
  if (config.id === "anthropic") {
    return callAnthropic(config, apiKey, messages);
  }

  // OpenAI-compatible (Groq, Gemini OpenAI compat, OpenAI, OpenRouter, Ollama)
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
  };

  if (apiKey) {
    headers["Authorization"] = `Bearer ${apiKey}`;
  }

  // OpenRouter extras
  if (config.id === "openrouter") {
    headers["HTTP-Referer"] = process.env.NEXT_PUBLIC_APP_URL || "https://nexa.app";
    headers["X-Title"] = "Nexa";
  }

  const res = await fetch(`${config.baseUrl}/chat/completions`, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: config.model,
      messages,
      temperature: 0.65,
      max_tokens: 2048,
    }),
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error(`[Nexa] ${config.id} error:`, errorText);
    return null;
  }

  const data = await res.json();
  return data.choices?.[0]?.message?.content || null;
}

async function callAnthropic(
  config: ProviderConfig,
  apiKey: string | null,
  messages: { role: string; content: string }[]
): Promise<string | null> {
  if (!apiKey) return null;

  // Convert messages for Anthropic
  const system = messages.find((m) => m.role === "system")?.content || "";
  const chatMessages = messages
    .filter((m) => m.role !== "system")
    .map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    }));

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: config.model,
      max_tokens: 2048,
      system,
      messages: chatMessages,
    }),
  });

  if (!res.ok) {
    const errorText = await res.text();
    console.error("[Nexa] Anthropic error:", errorText);
    return null;
  }

  const data = await res.json();
  return data.content?.[0]?.text || null;
}

/**
 * Fallback when no provider key is available.
 * Still uses business context so the product feels useful.
 */
function generateFallbackResponse(request: AIRequest): string {
  const lastUser =
    request.recentMessages.filter((m) => m.role === "user").pop()?.content || "";
  const lower = lastUser.toLowerCase();
  const biz = request.businessContext;
  const name = request.userName || biz?.name || "there";
  const business = biz?.businessName || "your business";

  // Scope enforcement
  if (
    /weather|temperature|forecast|what time is it|capital of|joke|romantic|love letter|homework|solve this equation/.test(
      lower
    )
  ) {
    return "I'm focused on helping with your business and professional growth. I don't handle general or personal non-business queries here. What business challenge can I help you with?";
  }

  const workspaceName = request.workspace.replace("_", " & ");

  if (request.workspace === "marketing") {
    return `Got it. Looking at **${business}** in Marketing.\n\nBased on what I know${biz?.targetCustomer || biz?.targetCustomers ? ` about your focus on ${biz.targetCustomer || biz.targetCustomers}` : ""}, here's how I'd approach this:\n\n1. Clarify the single most important acquisition channel right now.\n2. Define one clear offer/message for that channel.\n3. Run a tight 2-week experiment with clear success metrics.\n\nTell me the specific goal (more leads, better conversion, higher engagement, etc.) and I'll give you a concrete plan.`;
  }

  if (request.workspace === "sales") {
    return `In Sales for **${business}**.\n\nI can help with outreach sequences, objection handling, or improving conversion.\n\nTo make this specific: who are you reaching out to, what is the core offer, and what’s the main friction you're seeing right now?`;
  }

  if (request.workspace === "strategy") {
    return `Strategy workspace — let's think this through carefully for **${business}**.\n\nGood strategy starts with clarity on target customer, unique value, and current constraints.\n\nShare more about the decision or problem you're facing and I'll help you structure it.`;
  }

  if (request.workspace === "content_brand") {
    return `Content & Brand for **${business}**.\n\nI can draft posts, improve messaging, or help define a clearer brand voice.\n\nWhat do you need right now — a specific piece of copy, a content system, or a brand messaging review?`;
  }

  if (request.workspace === "personal_growth") {
    return `Personal Growth (professional focus).\n\nI can help with productivity systems, prioritization, founder mindset, and staying focused on what moves the business.\n\nWhat's the main friction in your work right now?`;
  }

  return `Understood, ${name}.\n\nI'm in the **${workspaceName}** workspace and I have your business context loaded${biz?.businessName ? ` for ${biz.businessName}` : ""}.\n\nHere's how I recommend we approach this:\n\n- Restate the core problem clearly\n- Identify the highest-leverage next action\n- Give you something concrete you can execute this week\n\nWhat would be most useful right now — a plan, specific copy/messages, a decision framework, or a review of something you already have?`;
}

/**
 * Website content fetcher (used by chat)
 */
export async function fetchWebsiteContent(url: string): Promise<string> {
  try {
    const res = await fetch("/api/fetch-website", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });
    const data = await res.json();
    if (!res.ok) {
      return `Could not fetch the website (${data.error || res.status}). Please paste the relevant content instead.`;
    }
    return data.content || "No readable content extracted from the page.";
  } catch {
    return "Could not fetch the website. Please paste the relevant content instead.";
  }
}
